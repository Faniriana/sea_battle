#include <SFML/Graphics.hpp>
#include <iostream>
#include <ctime>
using namespace std;

const int lignes = 10;
const int colonnes = 10;
const int maxBateaux = 5;
const int maxEssais = 50;

int matrice[lignes][colonnes];
bool revele[lignes][colonnes] = {false};

void Nettoyer()
{
    for (int i = 0; i < lignes; i++)
    {
        for (int j = 0; j < colonnes; j++)
        {
            matrice[i][j] = 0;
            revele[i][j] = false;
        }
    }
}

void PlacerBateaux()
{
    int s = 0;
    while (s < maxBateaux)
    {
        int x = rand() % lignes;
        int y = rand() % colonnes;
        if (matrice[x][y] != 1)
        {
            s++;
            matrice[x][y] = 1;
        }
    }
}

bool Attaquer(int x, int y)
{
    if (matrice[x][y] == 1)
    {
        matrice[x][y] = 2;
        return true;
    }
    return false;
}

int NombreDeBateaux()
{
    int c = 0;
    for (int i = 0; i < lignes; i++)
    {
        for (int j = 0; j < colonnes; j++)
        {
            if (matrice[i][j] == 1)
                c++;
        }
    }
    return c;
}

int main()
{
    srand(time(NULL));
    Nettoyer();
    PlacerBateaux();

    sf::RenderWindow fenetre(sf::VideoMode(600, 600), "Bataille Navale");

    sf::Font police;
    if (!police.loadFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
    {
        cerr << "Erreur de chargement de la police" << endl;
        return -1;
    }

    sf::Text texteEssais;
    texteEssais.setFont(police);
    texteEssais.setCharacterSize(20);
    texteEssais.setFillColor(sf::Color::White);
    texteEssais.setPosition(10, 560);

    sf::Text texteScore;
    texteScore.setFont(police);
    texteScore.setCharacterSize(20);
    texteScore.setFillColor(sf::Color::White);
    texteScore.setPosition(400, 560);

    int essais = 0;
    int score = 0;

    while (fenetre.isOpen())
    {
        sf::Event evenement;
        while (fenetre.pollEvent(evenement))
        {
            if (evenement.type == sf::Event::Closed)
                fenetre.close();
            else if (evenement.type == sf::Event::MouseButtonPressed)
            {
                if (essais >= maxEssais)
                {
                    cout << "Vous avez épuisé vos essais. Jeu terminé !" << endl;
                    fenetre.close();
                }

                int x = evenement.mouseButton.x / 60;
                int y = evenement.mouseButton.y / 60;
                revele[x][y] = true;

                if (Attaquer(x, y))
                {
                    //cout << "Vous m'avez eu ! :)" << endl;
                    score++;
                }
                //else
                //{
                  //  cout << "Désolé, pas de bateau à cette position !" << endl;
                //}
                essais++;
                //cout << "Nombre de bateaux restants : " << NombreDeBateaux() << endl;
                if (NombreDeBateaux() == 0)
                {
                    cout << "Félicitations ! Vous avez trouvé tous les bateaux !" << endl;
                    fenetre.close();
                }
                else if (essais >= maxEssais)
                {
                    cout << "GAME OVER! Vous avez épuisé vos essais. Jeu terminé !" << endl;
                    fenetre.close();
                }
            }
        }

        texteEssais.setString("Essais : " + to_string(essais) + "/" + to_string(maxEssais));
        texteScore.setString("Score : " + to_string(score));

        fenetre.clear();

        for (int i = 0; i < lignes; i++)
        {
            for (int j = 0; j < colonnes; j++)
            {
                sf::RectangleShape caseCellule(sf::Vector2f(60, 60));
                caseCellule.setPosition(i * 60, j * 60);
                caseCellule.setOutlineThickness(1);
                caseCellule.setOutlineColor(sf::Color::White);

                if (revele[i][j])
                {
                    if (matrice[i][j] == 1)
                    {
                        caseCellule.setFillColor(sf::Color::Black);
                    }
                    else if (matrice[i][j] == 2)
                    {
                        sf::CircleShape touche(30);
                        touche.setFillColor(sf::Color::Red);
                        touche.setPosition(i * 60, j * 60);
                        fenetre.draw(touche);
                        caseCellule.setFillColor(sf::Color::Transparent);
                    }
                    else
                    {
                        caseCellule.setFillColor(sf::Color(169, 169, 169));
                    }
                }
                else
                {
                    caseCellule.setFillColor(sf::Color::Transparent);
                }

                fenetre.draw(caseCellule);
            }
        }

        fenetre.draw(texteEssais);
        fenetre.draw(texteScore);

        fenetre.display();
    }

    return 0;
}
